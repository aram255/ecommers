<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Division;
use App\Models\District;

class DivisionsController extends Controller
{
   public function index(){
      $divisions = Division::orderBy('priority', 'asc')->get();
      return view('backend.pages.divisions.index', compact('divisions'));
    } 

      public function create(){
    	return view('backend.pages.divisions.create');
    }  

    public function store(Request $request){

       $this->validate($request, [
            'name'       => 'required',
            'priority'       => 'required',
           
        ],
        [
        	'name.required' => 'Please provide a Division name',
          'priority.required' => 'Please provide a Priority name',   
        ] );

      $divisions = new Division();
      $divisions->name = $request->name;
      $divisions->priority = $request->priority;
      $divisions->save();
      session()->flash('success', 'A new Division added successfully!!');
      return redirect()->route('admin.divisions');
    }


     public function edit($id){
        $divisions = Division::orderBy('name', 'desc')->get();
        $divisions = Division::find($id);
        if(!is_null($divisions)){
          return view('backend.pages.divisions.edit', compact('divisions'));
        }else{
          return redirect()->route('admin.divisions');
        }
      }

       public function update(Request $request, $id){

       $this->validate($request, [
            'name'       => 'required',
            'priority'       => 'required',
           
        ],
        [
          'name.required' => 'Please provide a Division name',
          'priority.required' => 'Please provide a Priority name',   
        ] );


      $divisions = Division::find($id);
      $divisions->name = $request->name;
      $divisions->priority = $request->priority;
    
      $divisions->save();
      session()->flash('success', 'Division has updated successfully!!');
      return redirect()->route('admin.divisions');
    }


public function delete($id){

      $divisions = Division::find($id);
      if(!is_null($divisions)){
         $districts = District::where('division_id', $divisions->id )->get();
         foreach ($districts as $district) {
           $district->delete();
         }

         $divisions->delete(); 
       }
      session()->flash('success', 'Division has deleted successfully !!');
      return back();

      }

}
