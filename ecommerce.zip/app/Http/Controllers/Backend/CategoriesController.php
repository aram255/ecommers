<?php

namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use Image;
use File;

class CategoriesController extends Controller
{
    public function index(){
      $categories = Category::orderBy('id', 'desc')->get();
      return view('backend.pages.categories.index', compact('categories'));
    } 

      public function create(){
      	  //$main_categories = Category::orderBy('name', 'desc')->where('parent_id', NULL)->get();
      	  $main_categories = Category::orderBy('name', 'desc')->get();
    	return view('backend.pages.categories.create', compact('main_categories'));
    }  

    public function store(Request $request){

       $this->validate($request, [
            'name'       => 'required|max:255',
           // 'image' => 'required|image',
        ],
        [
        	'name.required' => 'Please provide a category name',
        	//'image.required' => 'Please provide a valid image with .png, .jpeg, .gig extention...',
        ] );

      $category = new Category();
      $category->name = $request->name;
      $category->description = $request->description;
      $category->parent_id = $request->parent_id;

    // ProductImage Model Insert Image
      if ($request->hasFile('image')) {
        // Insert Image in Location
        $image = $request->file('image');
        $img = time() .'.'. $image->getClientOriginalExtension();
        $location = 'images/categories/'.$img;
        Image::make($image)->save($location); 
        $category->image = $img;
      }
      $category->save();
      session()->flash('success', 'A new category added successfully!!');
      return redirect()->route('admin.categories');
    }


     public function edit($id){
        $sub_categories = Category::orderBy('name', 'desc')->get();
        $category = Category::find($id);
        if(!is_null($category)){
          return view('backend.pages.categories.edit', compact('category', 'sub_categories'));
        }else{
          return redirect()->route('admin.categories');
        }
      }

       public function update(Request $request, $id){

       $this->validate($request, [
            'name'       => 'required|max:255',
           // 'image' => 'required|image',
        ],
        [
          'name.required' => 'Please provide a category name',
          //'image.required' => 'Please provide a valid image with .png, .jpeg, .gig extention...',
        ] );

      $category = Category::find($id);
      $category->name = $request->name;
      $category->description = $request->description;
      $category->parent_id = $request->parent_id;

    // ProductImage Model Insert Image
       if ($request->hasFile('image')) {
        // Delete the old image for folder

        if(File::exists('images/categories/'.$category->image)){
          File::delete('images/categories/'.$category->image);
        }

        $image = $request->file('image');
        $img = time() .'.'. $image->getClientOriginalExtension();
        $location = 'images/categories/'.$img;
        Image::make($image)->save($location); 
        $category->image = $img;
      }
      $category->save();
      session()->flash('success', 'Category has updated successfully!!');
      return redirect()->route('admin.categories');
    }


public function delete($id){

      $category = category::find($id);
      if(!is_null($category)){

    // delete sub category & image
        if($category->parent_id == NULL){
            $sub_categories = Category::orderBy('name', 'desc')->where('parent_id', $category->id)->get();
            foreach($sub_categories as $sub){
               if(File::exists('images/categories/'.$sub->image)){
                File::delete('images/categories/'.$sub->image);
              }
               $sub->delete();
            }
        }


        // delete category image
         if(File::exists('images/categories/'.$category->image)){
          File::delete('images/categories/'.$category->image);
        }

         $category->delete(); 
       }
      session()->flash('success', 'Category has deleted successfully !!');
      return back();

      }

}
