<?php

namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Brand;
use Image;
use File;

class BrandsController extends Controller
{
    public function index(){
      $brands = Brand::orderBy('id', 'desc')->get();
      return view('backend.pages.brands.index', compact('brands'));
    } 

      public function create(){
    	return view('backend.pages.brands.create');
    }  

    public function store(Request $request){

       $this->validate($request, [
            'name'       => 'required|max:255',
           // 'image' => 'required|image',
        ],
        [
        	'name.required' => 'Please provide a Brand name',
        	//'image.required' => 'Please provide a valid image with .png, .jpeg, .gig extention...',
        ] );

      $brands = new Brand();
      $brands->name = $request->name;
      $brands->description = $request->description;

    // ProductImage Model Insert Image
      if ($request->hasFile('image')) {
        // Insert Image in Location
        $image = $request->file('image');
        $img = time() .'.'. $image->getClientOriginalExtension();
        $location = 'images/brands/'.$img;  
        Image::make($image)->save($location); 
        $brands->image = $img;
      }
      $brands->save();
      session()->flash('success', 'A new Brand added successfully!!');
      return redirect()->route('admin.brands');
    }


     public function edit($id){
        $brands = Brand::orderBy('name', 'desc')->get();
        $brands = Brand::find($id);
        if(!is_null($brands)){
          return view('backend.pages.brands.edit', compact('brands'));
        }else{
          return redirect()->route('admin.brands');
        }
      }

       public function update(Request $request, $id){

       $this->validate($request, [
            'name'       => 'required|max:255',
           // 'image' => 'required|image',
        ],
        [
          'name.required' => 'Please provide a Brand name',
          //'image.required' => 'Please provide a valid image with .png, .jpeg, .gig extention...',
        ] );

      $brands = Brand::find($id);
      $brands->name = $request->name;
      $brands->description = $request->description;

    // ProductImage Model Insert Image
       if ($request->hasFile('image')) {
        // Delete the old image for folder

        if(File::exists('images/brands/'.$brands->image)){
          File::delete('images/brands/'.$brands->image);
        }

        $image = $request->file('image');
        $img = time() .'.'. $image->getClientOriginalExtension();
        $location = 'images/brands/'.$img;
        Image::make($image)->save($location); 
        $brands->image = $img;
      }
      $brands->save();
      session()->flash('success', 'Brand has updated successfully!!');
      return redirect()->route('admin.brands');
    }


public function delete($id){

      $brands = Brand::find($id);
      if(!is_null($brands)){
        // delete Brand image
         if(File::exists('images/brands/'.$brands->image)){
          File::delete('images/brands/'.$brands->image);
        }

         $brands->delete(); 
       }
      session()->flash('success', 'Brand has deleted successfully !!');
      return back();

      }

}
