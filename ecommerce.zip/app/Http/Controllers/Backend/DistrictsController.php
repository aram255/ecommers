<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\District;
use App\Models\Division;

class DistrictsController extends Controller
{
    public function index(){
      $districts = District::orderBy('id', 'asc')->get();
      return view('backend.pages.districts.index', compact('districts'));
    } 

      public function create(){
      	$divisions = Division::orderBy('priority', 'asc')->get();
    	return view('backend.pages.districts.create',compact('divisions'));
    }  

    public function store(Request $request){

       $this->validate($request, [
            'name'       => 'required',
            'division_id'       => 'required',
           
        ],
        [
        	'name.required' => 'Please provide a District name',
          'division_id.required' => 'Please select a Division name',   
        ] );

      $districts = new District();
      $districts->name = $request->name;
      $districts->division_id = $request->division_id;
      $districts->save();
      session()->flash('success', 'A new District added successfully!!');
      return redirect()->route('admin.districts');
    }


     public function edit($id){
       $divisions = Division::orderBy('priority', 'asc')->get();
        $districts = District::find($id);
        if(!is_null($divisions)){
          return view('backend.pages.districts.edit', compact('districts','divisions'));
        }else{
          return redirect()->route('admin.districts');
        }
      }

       public function update(Request $request, $id){

       $this->validate($request, [
             'name'       => 'required',
            'division_id'       => 'required',
           
        ],
        [
        	'name.required' => 'Please provide a District name',
          'division_id.required' => 'Please select a Division name',   
        ] );

      $districts = District::find($id);
      $districts->name = $request->name;
      $districts->division_id = $request->division_id;
    
      $districts->save();
      session()->flash('success', 'District has updated successfully!!');
      return redirect()->route('admin.districts');
    }


public function delete($id){

      $districts = District::find($id);
      if(!is_null($districts)){
         $districts->delete(); 
       }
      session()->flash('success', 'District has deleted successfully !!');
      return back();

      }

}
