<!-- plugins:js -->
  <script src="<?php echo e(asset('js/jquery-3.3.1.slim.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/popper.min.js')); ?>" ></script>
  <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>



  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(asset('js/misc.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5NXz9eVnyJOA81wimI8WYE08kW_JMe8g&callback=initMap" async defer></script>
  <script src="<?php echo e(asset('js/maps.js')); ?>"></script>
  <!-- End custom js for this page-->
<?php /* G:\xampp\htdocs\ecommerce\resources\views/admin/partials/script.blade.php */ ?>