<?php $__env->startSection('title'); ?>
Admin :: Update District
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Update District</h3>
            </div>
            <div class="card-body">
              <?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <form action="<?php echo e(route('admin.district.update',  $districts->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                  <label for="exampleInputEmail1">District Name</label>
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($districts->name); ?>">
                </div>

                 <div class="form-group">
                  <select class="form-control" name="division_id">
                    <option value="">Select Division</option>
                    <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($division->id); ?>" <?php echo e($division->id ==  $districts->division_id ? 'selected' : ''); ?>><?php echo e($division->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>

 

                <button type="submit" class="btn btn-primary">Update District</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/pages/districts/edit.blade.php */ ?>