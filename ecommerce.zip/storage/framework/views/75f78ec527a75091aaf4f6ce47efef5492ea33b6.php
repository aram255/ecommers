<!--Footer-->
      <footer class="footer-bottom">
        <p class="text-center">eCommerce Website | Design & Development By &copy; Faisal</p>
      </footer>
      <!--Footer End-->
<?php /* G:\xampp\htdocs\ecommerce\resources\views/partials/footer.blade.php */ ?>