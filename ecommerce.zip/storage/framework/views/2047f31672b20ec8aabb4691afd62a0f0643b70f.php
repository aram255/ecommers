<!-- [ navigation menu ] start -->
<nav class="pcoded-navbar">
    <div class="nav-list">
        <div class="pcoded-inner-navbar main-menu">  

            <ul class="pcoded-item pcoded-left-item">
                <li class="pcoded-hasmenu active pcoded-trigger">
                    <a href="<?php echo e(route('admin.index')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                        <span class="pcoded-mtext">Dashboard</span>
                    </a>
                </li>

                   <li class="pcoded-hasmenu">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="feather icon-package"></i></span>
                        <span class="pcoded-mtext">Manage Categories</span>   
                    </a>
                    <ul class="pcoded-submenu">
                        <li>
                            <a href="<?php echo e(route('admin.category.create')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Add Category</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="<?php echo e(route('admin.categories')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Categories List</span>
                            </a>
                        </li>
                    </ul>
                </li>


                <li class="pcoded-hasmenu">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                      <span class="pcoded-micon">
                        <i class="feather icon-layers"></i>
                      </span>
                      <span class="pcoded-mtext">Manage Brands</span>  
                    </a>
                    <ul class="pcoded-submenu">
                        <li>
                            <a href="<?php echo e(route('admin.brand.create')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Add Brand</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="<?php echo e(route('admin.brands')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Brands List</span>
                            </a>
                        </li>
                    </ul>
                </li>

                 <li class="pcoded-hasmenu">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                      <span class="pcoded-micon">
                        <i class="feather icon-layers"></i>
                      </span>
                      <span class="pcoded-mtext">Manage Divisions</span>  
                    </a>
                    <ul class="pcoded-submenu">
                        <li>
                            <a href="<?php echo e(route('admin.division.create')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Add Division</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="<?php echo e(route('admin.divisions')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Divisions List</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="pcoded-hasmenu">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                      <span class="pcoded-micon">
                        <i class="feather icon-layers"></i>
                      </span>
                      <span class="pcoded-mtext">Manage Districts</span>  
                    </a>
                    <ul class="pcoded-submenu">
                        <li>
                            <a href="<?php echo e(route('admin.district.create')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Add District</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="<?php echo e(route('admin.districts')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Districts List</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="pcoded-hasmenu">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="feather icon-sidebar"></i></span>
                        <span class="pcoded-mtext">Manage Products</span>   
                    </a>
                    <ul class="pcoded-submenu">
                        <li>
                            <a href="<?php echo e(route('admin.product.create')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Add Product</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="<?php echo e(route('admin.products.manage')); ?>" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Products List</span>
                            </a>
                        </li>
                    </ul>
                </li>

                  <li class="">
                    <a href="navbar-light.html" class="waves-effect waves-dark">
                      <span class="pcoded-micon">
                        <i class="feather icon-menu"></i>
                      </span>
                     <span class="pcoded-mtext">Navigation</span>
                    </a>
                </li>

            </ul>


            <ul class="pcoded-item pcoded-left-item">
                <li class="pcoded-hasmenu">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                      <span class="pcoded-micon">
                        <i class="feather icon-box"></i>
                      </span>
                        <span class="pcoded-mtext">Basic</span>
                    </a>
                    <ul class="pcoded-submenu">
                        <li class="">
                            <a href="#" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Alert</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="breadcrumb.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Breadcrumbs</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="pcoded-hasmenu">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
      <span class="pcoded-micon">
        <i class="feather icon-gitlab"></i>
      </span>
                        <span class="pcoded-mtext">Advance</span>
                    </a>
                    <ul class="pcoded-submenu">
                        <li class=" ">
                            <a href="draggable.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Draggable</span>
                            </a>
                        </li>


                        </li>
                        <li class=" ">
                            <a href="modal.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Modal</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="notification.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Notifications</span>
                            </a>
                        </li>

                        <li class=" ">
                            <a href="rating.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Rating</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="range-slider.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Range Slider</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="slider.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Slider</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="syntax-highlighter.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Syntax Highlighter</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="tour.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Tour</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="treeview.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Tree View</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="nestable.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Nestable</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="toolbar.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Toolbar</span>
                            </a>
                        </li>

                    </ul>

                </li>
                <li class="pcoded-hasmenu">
                    <a href="javascript:void(0)" class="waves-effect waves-dark">
      <span class="pcoded-micon">
        <i class="feather icon-package"></i>
      </span>
                        <span class="pcoded-mtext">Extra</span>
                    </a>
                    <ul class="pcoded-submenu">
                        <li class=" ">
                            <a href="session-timeout.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Session Timeout</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="session-idle-timeout.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Session Idle Timeout</span>
                            </a>
                        </li>
                        <li class=" ">
                            <a href="offline.html" class="waves-effect waves-dark">
                                <span class="pcoded-mtext">Offline</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class=" ">
                    <a href="animation.html" class="waves-effect waves-dark">
                          <span class="pcoded-micon">
                            <i class="feather icon-aperture rotate-refresh"></i>
                          </span>
                          <span class="pcoded-mtext">Animations</span>
                    </a>
                </li>                                   
            </ul>     
        </div>
    </div>
</nav>
<!-- [ navigation menu ] end -->
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/partials/left_menu.blade.php */ ?>