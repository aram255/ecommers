<?php $__env->startSection('content'); ?>
      <!--Sidebar + Content Start-->
      <div class="container margin-top-20">
        <div class="row">
          <div class="col-md-4"> 
             <?php echo $__env->make('partials.product-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>

          <div class="col-md-8">
            <div class="widget">
              <h3>Feature Products</h3>
             <div class="row">

               <div class="col-md-3">
                 <div class="card text-center">
                  <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/'. 'product-1.jpg')); ?>" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Samsung</h5>
                    <p class="card-text">Taka-500</p>
                    <a href="#" class="btn btn-outline-warning">Add to Card</a>
                  </div>
                </div>
               </div>

              <div class="col-md-3">
                 <div class="card text-center">
                  <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/product-1.jpg')); ?>" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Samsung</h5>
                    <p class="card-text">Taka-500</p>
                    <a href="#" class="btn btn-outline-warning">Add to Card</a>
                  </div>
                </div>
               </div>

                <div class="col-md-3">
                 <div class="card text-center">
                  <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/product-1.jpg')); ?>" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Samsung</h5>
                    <p class="card-text">Taka-500</p>
                    <a href="#" class="btn btn-outline-warning">Add to Card</a>
                  </div>
                </div>
               </div>

                <div class="col-md-3">
                 <div class="card text-center">
                  <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/product-1.jpg')); ?>" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Samsung</h5>
                    <p class="card-text">Taka-500</p>
                    <a href="#" class="btn btn-outline-warning">Add to Card</a>
                  </div>
                </div>
               </div>
             
              <div class="col-md-3">
                 <div class="card text-center">
                  <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/product-1.jpg')); ?>" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Samsung</h5>
                    <p class="card-text">Taka-500</p>
                    <a href="#" class="btn btn-outline-warning">Add to Card</a>
                  </div>
                </div>
               </div>

                <div class="col-md-3">
                 <div class="card text-center">
                  <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/product-1.jpg')); ?>" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Samsung</h5>
                    <p class="card-text">Taka-500</p>
                    <a href="#" class="btn btn-outline-warning">Add to Card</a>
                  </div>
                </div>
               </div>
                <div class="col-md-3">
                 <div class="card text-center">
                  <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/product-1.jpg')); ?>" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Samsung</h5>
                    <p class="card-text">Taka-500</p>
                    <a href="#" class="btn btn-outline-warning">Add to Card</a>
                  </div>
                </div>
               </div>
             
              <div class="col-md-3">
                 <div class="card text-center">
                  <img class="card-img-top feature-img" src="<?php echo e(asset('images/products/product-1.jpg')); ?>" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">Samsung</h5>
                    <p class="card-text">Taka-500</p>
                    <a href="#" class="btn btn-outline-warning">Add to Card</a>
                  </div>
                </div>
               </div>

              </div>
             </div>
          </div>
        </div>
      </div>
      <!--Sidebar + Content End-->
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/pages/index.blade.php */ ?>