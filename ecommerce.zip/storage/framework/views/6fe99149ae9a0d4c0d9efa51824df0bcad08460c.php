[<?php echo e($slot); ?>](<?php echo e($url); ?>)

<?php /* G:\xampp\htdocs\ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php */ ?>