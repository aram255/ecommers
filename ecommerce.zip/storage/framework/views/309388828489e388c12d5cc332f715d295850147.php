<?php $__env->startSection('content'); ?>
      <div class="pcoded-content">
                        <!-- [ breadcrumb ] start -->
                        <div class="page-header card">
                            <div class="row align-items-end">
                              
                                   <div class="col-lg-12">
                                                <div class="card sale-card">
                                                    <div class="card-header">
                                                          <div class="page-header-title">
                                                            <i class="feather icon-home bg-c-blue"></i>
                                                            <div class="d-inline">
                                                                <h5>Welcome to your Admin Panel</h5>
                                                            </div>
                                                        </div><br><br>
                                                         <a href="<?php echo e(route('index')); ?>" class="btn btn-primary" style="display:table;" target="_blank">Visit Your Website</a>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- [ page content ] end -->
                                    </div>
                                </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/pages/index.blade.php */ ?>