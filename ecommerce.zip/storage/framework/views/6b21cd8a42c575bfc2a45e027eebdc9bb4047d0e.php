    <!-- Warning Section Starts -->
    <!-- Older IE warning message -->
    
    <!-- Warning Section Ends -->
    <!-- Required Jquery -->
    <script data-cfasync="false" src="<?php echo e(asset('./../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('./files/bower_components/jquery/js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('./files/bower_components/jquery-ui/js/jquery-ui.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('./files/bower_components/popper.js/js/popper.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('./files/bower_components/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <!-- waves js -->
    <script src="<?php echo e(asset('./files/assets/pages/waves/js/waves.min.js')); ?>"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo e(asset('./files/bower_components/jquery-slimscroll/js/jquery.slimscroll.js')); ?>"></script>
    <!-- Float Chart js -->
    <script src="<?php echo e(asset('./files/assets/pages/chart/float/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset('./files/assets/pages/chart/float/jquery.flot.categories.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>./files/assets/pages/chart/float/curvedLines.js"></script>
    <script src="<?php echo e(asset('./files/assets/pages/chart/float/jquery.flot.tooltip.min.js')); ?>"></script>
    <!-- Chartlist charts -->
    <script src="<?php echo e(asset('./files/bower_components/chartist/js/chartist.js')); ?>"></script>
    <!-- amchart js -->
    <script src="<?php echo e(asset('./files/assets/pages/widget/amchart/amcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('./files/assets/pages/widget/amchart/serial.js')); ?>"></script>
    <script src="<?php echo e(asset('./files/assets/pages/widget/amchart/light.js')); ?>"></script>
    <!-- Custom js -->
    <script src="<?php echo e(asset('./files/assets/js/pcoded.min.js')); ?>"></script>
    <script src="<?php echo e(asset('./files/assets/js/vertical/vertical-layout.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('./files/assets/pages/dashboard/custom-dashboard.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('./files/assets/js/script.min.js')); ?>"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="<?php echo e(asset('../../../../www.googletagmanager.com/gtag/jsa055?id=UA-23581568-13')); ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/partials/footer.blade.php */ ?>