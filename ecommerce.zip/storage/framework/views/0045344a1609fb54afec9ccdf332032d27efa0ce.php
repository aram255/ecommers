<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo $__env->yieldContent('title', 'Admin :: Dashboard'); ?></title>
  <?php echo $__env->make('backend.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
     <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-bar"></div>
    </div>
    <!-- [ Pre-loader ] end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

            <?php echo $__env->make('backend.partials.top_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('backend.partials.sidebar_chat_show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">

                   <?php echo $__env->make('backend.partials.left_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                   <?php echo $__env->yieldContent('content'); ?>

                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->make('backend.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
</body>
</html>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/layouts/master.blade.php */ ?>