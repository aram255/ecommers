<?php $__env->startSection('title'); ?>
Admin :: Add New Product
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Add New Products</h3>
            </div>
            <div class="card-body">
              <?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <form action="<?php echo e(route('admin.product.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="exampleInputEmail1">Title</label>
                  <input type="text" class="form-control" name="title" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Title">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                  <textarea name="description" rows="8" cols="80" class="form-control"></textarea>

                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Price</label>
                  <input type="number" class="form-control" name="price" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Quantity</label>
                  <input type="number" class="form-control" name="quantity" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                </div>

                <div class="form-group">
                  <label for="product_image">Product Image</label>
                  <div class="row">
                    <div class="col-md-4">
                      <input type="file" class="form-control" name="product_image[]">
                    </div>

                    <div class="col-md-4">
                      <input type="file" class="form-control" name="product_image[]">
                    </div>

                    <div class="col-md-4">
                      <input type="file" class="form-control" name="product_image[]">
                    </div>

                    <div class="col-md-4">
                      <input type="file" class="form-control" name="product_image[]">
                    </div>

                    <div class="col-md-4">
                      <input type="file" class="form-control" name="product_image[]">
                    </div>
                  </div>
                </div>

                <button type="submit" class="btn btn-primary">Add Product</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/pages/product/create.blade.php */ ?>