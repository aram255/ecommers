  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/simple-line-icons.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/admin_style.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />
<?php /* G:\xampp\htdocs\ecommerce\resources\views/admin/partials/style.blade.php */ ?>