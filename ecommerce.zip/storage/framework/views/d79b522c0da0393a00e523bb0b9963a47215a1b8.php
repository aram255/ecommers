<?php $__env->startSection('content'); ?>
      <!--Sidebar + Content Start-->
      <div class="container margin-top-20">
        <div class="row">
          <div class="col-md-4">
            <?php echo $__env->make('frontend.partials.product-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>

          <div class="col-md-8">
            <div class="widget">
              <h3>Search for <span class="badge badge-primary"><?php echo e($search); ?></span></h3>
               <?php echo $__env->make('frontend.pages.product.partials.all_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             </div>
          </div>
        </div>
      </div>
      <!--Sidebar + Content End-->
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/frontend/pages/product/search.blade.php */ ?>