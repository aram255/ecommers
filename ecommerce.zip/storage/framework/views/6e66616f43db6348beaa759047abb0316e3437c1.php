<?php $__env->startSection('title'); ?>
Admin :: Update Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Update Category</h3>
            </div>
            <div class="card-body">
              <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <form action="<?php echo e(route('admin.category.update',  $category->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                  <label for="exampleInputEmail1">Category Name</label>
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($category->name); ?>">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                  <textarea name="description" rows="8" cols="80" class="form-control"><?php echo e($category->description); ?></textarea>

                </div>

                 <div class="form-group">
                  <label for="parent">Parent Category</label>
                  <select class="form-control" name="parent_id" id="parent">
                      <option value="">Select a primary category</option>
                    <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->parent_id); ?>" <?php echo e($cat->id == $category->parent_id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                

                <div class="form-group">
                  <label for="product_image">Category Image</label>
                  <img src="<?php echo e(asset('images/categories/'.$category->image)); ?>" alt="category image" width="100">
                  <input type="file" class="form-control" name="image">              
                </div>

                <button type="submit" class="btn btn-primary">Update Category</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/pages/categories/edit.blade.php */ ?>