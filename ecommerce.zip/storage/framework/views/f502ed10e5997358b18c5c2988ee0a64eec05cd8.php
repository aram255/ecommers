  <!-- Required meta tags -->
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Admindek Bootstrap admin template made using Bootstrap 4 and it has huge amount of ready made feature, UI components, pages which completely fulfills any dashboard needs." />
    <meta name="keywords" content="flat ui, admin Admin , Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
    <meta name="author" content="colorlib" />
    <!-- Favicon icon -->
    <link rel="icon" href="<?php echo e(asset('./files/assets/images/favicon.ico')); ?>" type="image/x-icon">
    <!-- Google font-->
    <link href="<?php echo e(asset('../../../../fonts.googleapis.com/css0f7c.css?family=Open+Sans:300,400,600,700,800')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('../../../../fonts.googleapis.com/css1180.css?family=Quicksand:500,700')); ?>" rel="stylesheet">
    <!-- Required Fremwork -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('./files/bower_components/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- waves.css -->
    <link rel="stylesheet" href="<?php echo e(asset('./files/assets/pages/waves/css/waves.min.css')); ?>" type="text/css" media="all">
    <!-- feather icon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('./files/assets/icon/feather/css/feather.css')); ?>">
    <!-- font-awesome-n -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('./files/assets/css/font-awesome-n.min.css')); ?>">
    <!-- Chartlist chart css -->
    <link rel="stylesheet" href="<?php echo e(asset('./files/bower_components/chartist/css/chartist.css')); ?>" type="text/css" media="all">
    <!-- Style.css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('./files/assets/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('./files/assets/css/widget.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/custom.css')); ?>">
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/partials/style.blade.php */ ?>