<?php $__env->startSection('title'); ?>
User Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sub-content'); ?>
<!--User Content Start-->
  <div class="container card">

    <h3>Welcome To <?php echo e($user->first_name.' '.$user->last_name); ?></h3>
    <p>You can change your profile and every information here!!</p>
  </div>

<!--User Content End-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.pages.users.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/frontend/pages/users/dashboard.blade.php */ ?>