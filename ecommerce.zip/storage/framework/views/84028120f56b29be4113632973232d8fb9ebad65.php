<ul class="list-group">
	<?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#main-<?php echo e($parent->id); ?>" class="list-group-item" data-toggle="collapse">  
        	<img src="<?php echo e(asset('images/categories/'.$parent->image )); ?>" width="60px" alt="category image"> <?php echo e($parent->name); ?> 
        </a>

        <div id="main-<?php echo e($parent->id); ?>" class="collapse
             <?php if(Route::is('categories.show') ): ?> 
                <?php if(App\Models\Category::parentorNotCategory($parent->id, $category->id)): ?>
                    show
                <?php endif; ?>
            <?php endif; ?>
            ">
          <?php $__currentLoopData = App\Models\Category::orderBy('name', 'asc')->where('parent_id', $parent->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('categories.show', $child->id)); ?>" class="list-group-item child_row 
            <?php if(Route::is('categories.show') ): ?> 
                <?php if($child->id == $category->id): ?>
                    active
                <?php endif; ?>
            <?php endif; ?>
            " style="padding-left: 71px;">  
        	<img src="<?php echo e(asset('images/categories/'.$child->image )); ?>" width="60px" alt="category image"> <?php echo e($child->name); ?> 
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/frontend/partials/product-sidebar.blade.php */ ?>