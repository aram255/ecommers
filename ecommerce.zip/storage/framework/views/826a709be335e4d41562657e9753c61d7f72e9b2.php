     <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="profile-image"> <img src="<?php echo e(asset('images/faces/face4.jpg')); ?>" alt="image"/> <span class="online-status online"></span> </div>
              <div class="profile-name">
                <p class="name">Project Admin</p>
                <p class="designation">Manager</p>
                <div class="badge badge-teal mx-auto mt-3">Online</div>
              </div>
            </div>
          </li>
          <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.index')); ?>"><img class="menu-icon" src="<?php echo e(asset('images/menu_icons/01.png')); ?>" alt="menu icon"><span class="menu-title">Dashboard</span></a></li>

          <li class="nav-item">
              <div id="MainMenu">
                  <div class=" panel">
                    <a href="#demo4" class="list-group-item list-group-item-success" data-toggle="collapse" data-parent="#MainMenu"><img class="menu-icon" src="http://localhost/ecommerce/public/images/menu_icons/07.png" alt="menu icon">Products<i class="fa fa-caret-down"></i></a>
                    <div class="collapse" id="demo4">
                      <a class="nav-link" href="<?php echo e(route('admin.product.create')); ?>"><img class="menu-icon" src="<?php echo e(asset('images/menu_icons/02.png')); ?>" alt="menu icon"><span class="menu-title">Add New Product</span></a>

                      <a class="nav-link" href="<?php echo e(route('admin.products.manage')); ?>"><img class="menu-icon" src="<?php echo e(asset('images/menu_icons/02.png')); ?>" alt="menu icon"><span class="menu-title">Manage Product</span></a>
                    </div>
                  </div>
              </div>
          </li>
        </ul>
      </nav>
      <!-- partial -->
<?php /* G:\xampp\htdocs\ecommerce\resources\views/admin/partials/left_menu.blade.php */ ?>