<?php $__env->startSection('title'); ?>
Admin :: Update Brand
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Update Division</h3>
            </div>
            <div class="card-body">
              <?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <form action="<?php echo e(route('admin.division.update',  $divisions->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                  <label for="exampleInputEmail1">Division Name</label>
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($divisions->name); ?>">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Division Priority</label>
                  <input type="text" class="form-control" name="priority" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($divisions->priority); ?>">
                </div>

 

                <button type="submit" class="btn btn-primary">Update Division</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* G:\xampp\htdocs\ecommerce\resources\views/backend/pages/divisions/edit.blade.php */ ?>