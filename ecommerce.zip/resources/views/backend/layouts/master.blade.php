<!DOCTYPE html>
<html lang="en">
<head>
  <title>@yield('title', 'Admin :: Dashboard')</title>
  @include('backend.partials.style')
</head>
<body>
     <!-- [ Pre-loader ] start -->
    <div class="loader-bg">
        <div class="loader-bar"></div>
    </div>
    <!-- [ Pre-loader ] end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

            @include('backend.partials.top_menu')
            @include('backend.partials.sidebar_chat_show')

            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">

                   @include('backend.partials.left_menu') 
                   @yield('content')

                </div>
            </div>
        </div>
    </div>

 @include('backend.partials.script')
 
</body>
</html>