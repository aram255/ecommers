@extends('backend.layouts.master')
@section('title')
Admin :: Add New Division
@endsection
@section('content')
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Add New Division</h3>
            </div>
            <div class="card-body">
              @include('backend.partials.message')
             <form action="{{ route('admin.division.store') }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}

                <div class="form-group">
                  <label for="exampleInputEmail1">Division Name</label>
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter division">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Division Priority</label>
                       <input type="text" class="form-control" name="priority" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Priority">

                </div>

                <button type="submit" class="btn btn-primary">Add Division</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
@endsection