@extends('backend.layouts.master')
@section('title')
Admin :: Update Brand
@endsection
@section('content')
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Update Division</h3>
            </div>
            <div class="card-body">
              @include('backend.partials.message')
             <form action="{{ route('admin.division.update',  $divisions->id) }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}

                <div class="form-group">
                  <label for="exampleInputEmail1">Division Name</label>
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{ $divisions->name }}">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Division Priority</label>
                  <input type="text" class="form-control" name="priority" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{ $divisions->priority }}">
                </div>

 

                <button type="submit" class="btn btn-primary">Update Division</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
@endsection