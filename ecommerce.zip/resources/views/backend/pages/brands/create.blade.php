@extends('backend.layouts.master')
@section('title')
Admin :: Add New Brand
@endsection
@section('content')
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Add New Brand</h3>
            </div>
            <div class="card-body">
              @include('backend.partials.message')
             <form action="{{ route('admin.brand.store') }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}

                <div class="form-group">
                  <label for="exampleInputEmail1">Brand Name</label>
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter brand">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                  <textarea name="description" rows="8" cols="80" class="form-control"></textarea>

                </div>


                <div class="form-group">
                  <label for="product_image">Brand Image</label>
                      <input type="file" class="form-control" name="image">              
                </div>

                <button type="submit" class="btn btn-primary">Add Brand</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
@endsection