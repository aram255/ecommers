@extends('backend.layouts.master')
@section('title')
Admin :: Manage All brands
@endsection
@section('content')
   <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Manage All Brands</h3>
            </div>
            <div class="card-body">
               @include('backend.partials.message')
                <table class="table table-bordered">
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Brands Name</th>
                      <th scope="col">Brands Image</th>
                    <th width="20%"scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  @php $i = 0;  @endphp
                   @foreach($brands as $brand)
                   
                   @php $i++;  @endphp
                  <tr>
                    <th scope="row">{{ $i }}</th>
                    <td>{{ $brand->name }}</td>
                   <td><img src="{{ asset('images/brands/'.$brand->image) }}" alt="brand image" width="50"></td>
                    <td>
                      <a href="{{ route('admin.brand.edit', $brand->id) }}" class="btn btn-primary">Edit</a>
                     <!-- Trigger the modal with a button -->


                     <a href="#deleteModal{{ $brand->id }}"  data-toggle="modal" class="btn btn-danger">Delete</a>

                    <!-- Delete Modal -->
                    <div id="deleteModal{{ $brand->id }}" class="modal fade" role="dialog">
                      <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                          <div class="modal-header"> 
                            <h4 class="modal-title">Are you sure delete this product</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                          </div>
                          <div class="modal-body">
                            <form action="{{ route('admin.brand.delete', $brand->id) }}" method="post">
                               {{ csrf_field() }}
                              <button type="submit" class="btn btn-danger">Permanent Delete</button>
                            </form>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
                          </div>
                        </div>

                      </div>
                    </div>
                    </td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
@endsection