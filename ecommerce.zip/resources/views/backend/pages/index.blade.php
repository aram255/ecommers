@extends('backend.layouts.master')
@section('content')
      <div class="pcoded-content">
                        <!-- [ breadcrumb ] start -->
                        <div class="page-header card">
                            <div class="row align-items-end">
                              
                                   <div class="col-lg-12">
                                                <div class="card sale-card">
                                                    <div class="card-header">
                                                          <div class="page-header-title">
                                                            <i class="feather icon-home bg-c-blue"></i>
                                                            <div class="d-inline">
                                                                <h5>Welcome to your Admin Panel</h5>
                                                            </div>
                                                        </div><br><br>
                                                         <a href="{{ route('index') }}" class="btn btn-primary" style="display:table;" target="_blank">Visit Your Website</a>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- [ page content ] end -->
                                    </div>
                                </div> 
@endsection