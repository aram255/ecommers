@extends('backend.layouts.master')
@section('title')
Admin :: Update Category
@endsection
@section('content')
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Update Category</h3>
            </div>
            <div class="card-body">
              @include('backend.partials.message')
             <form action="{{ route('admin.category.update',  $category->id) }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}

                <div class="form-group">
                  <label for="exampleInputEmail1">Category Name</label>
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{ $category->name }}">
                </div>

                <div class="form-group">
                  <label for="exampleInputPassword1">Description</label>
                  <textarea name="description" rows="8" cols="80" class="form-control">{{ $category->description }}</textarea>

                </div>

                 <div class="form-group">
                  <label for="parent">Parent Category</label>
                  <select class="form-control" name="parent_id" id="parent">
                      <option value="">Select a primary category</option>
                    @foreach($sub_categories as $cat)
                    <option value="{{ $cat->parent_id }}" {{ $cat->id == $category->parent_id ? 'selected' : '' }}>{{ $cat->name }}</option>
                    @endforeach
                  </select>
                </div>
                

                <div class="form-group">
                  <label for="product_image">Category Image</label>
                  <img src="{{ asset('images/categories/'.$category->image) }}" alt="category image" width="100">
                  <input type="file" class="form-control" name="image">              
                </div>

                <button type="submit" class="btn btn-primary">Update Category</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
@endsection