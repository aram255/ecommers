@extends('backend.layouts.master')
@section('title')
Admin :: Add New District
@endsection
@section('content')
      <div class="pcoded-content">
        <div class="content-wrapper">       
          <div class="card">
            <div class="card-header">
              <h3>Add New District</h3>
            </div>
            <div class="card-body">
              @include('backend.partials.message')
             <form action="{{ route('admin.district.store') }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}

                <div class="form-group">
                  <label for="exampleInputEmail1">District Name</label>
                  <input type="text" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter District">
                </div>

                <div class="form-group">
                  <select class="form-control" name="division_id">
                    <option value="">Select Division</option>
                    @foreach($divisions as $division)
                      <option value="{{ $division->id }}">{{ $division->name }}</option>
                    @endforeach
                  </select>
                </div>

                <button type="submit" class="btn btn-primary">Add District</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- main-panel ends -->
@endsection