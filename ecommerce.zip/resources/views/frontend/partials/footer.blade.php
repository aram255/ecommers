<!--Footer-->
      <div class="card footer">
      	<footer class="card-body">
        <p class="text-center">eCommerce Website | Design & Development By &copy; Faisal</p>
      </footer>
  </div>
      <!--Footer End-->