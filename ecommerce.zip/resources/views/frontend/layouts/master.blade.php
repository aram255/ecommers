<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
      @yield('title', 'Laravel eCommerce Project')
    </title>
    @include('frontend.partials.styles')
    @yield('stylesheet') 
  </head>
  <body>
    <div class="wrapper">

      @include('frontend.partials.nav')
      @include('frontend.partials.message')

      @yield('content')

      @include('frontend.partials.footer')
      
    </div>
     @include('frontend.partials.scripts')
  </body>
</html>