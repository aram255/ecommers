@extends('frontend.layouts.master')
@section('content')
      <!--Sidebar + Content Start-->
      <div class="container margin-top-20">
        <div class="row">
          <div class="col-md-3"> 
           <div class="list-group">
           	<a href="" class="list-group-item text-center">  
                <img src="{{ App\Helpers\ImageHelper::getUserImage(Auth::user()->id) }}" class="img rounded-ciecle" style="width:100px;"> <br>
                <h3>{{ Auth::user()->first_name.' '.Auth::user()->last_name }}</h3>
               </a>
               	<a href="{{ route('user.dashboard') }}" class="list-group-item {{ Route::is('user.dashboard') ? 'active' : '' }}">Dashboard</a>

                <a href="{{ route('user.profile') }}" class="list-group-item {{ Route::is('user.profile') ? 'active' : '' }}">Update Profile</a>
               	<a href="" class="list-group-item">Logout</a>
          </div>
        </div>

          <div class="col-md-9">
            @yield('sub-content')
          </div>
        </div>
      </div>
      <!--Sidebar + Content End-->
      @endsection