@extends('frontend.pages.users.master')
@section('title')
User Dashboard
@endsection
@section('sub-content')
<!--User Content Start-->
  <div class="container card">

    <h3>Welcome To {{ $user->first_name.' '.$user->last_name }}</h3>
    <p>You can change your profile and every information here!!</p>
  </div>

<!--User Content End-->
@endsection