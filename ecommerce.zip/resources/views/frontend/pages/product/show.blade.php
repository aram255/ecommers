@extends('frontend.layouts.master')
@section('title')
{{ $product->title }} | Laravel eCommerce Project
@endsection
@section('content')
      <!--Sidebar + Content Start-->
      <div class="container margin-top-20">
        <div class="row">
          <div class="col-md-4" id="product_image">
              <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                  @php $i = 1; @endphp
                    @foreach($product->images as $image)
                    <div class="carousel-item {{ $i == 1 ? 'active':'' }}">
                        <img class="d-block w-100" src="{{ asset('images/products/'. $image->image) }}" alt="First slide">
                    </div>
                     @php $i ++; @endphp
                    @endforeach
                 <p class="badge badge-primary">Category in -</p> {{ $product->category->name }} || <p class="badge badge-primary">Brand in -</p> {{ $product->brand->name }}

                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
              
          </div>

          <div class="col-md-8">
            <div class="widget">
              <h3>{{ $product->title }} </h3>
               <h5>{{ $product->price }} Taka 
                <span class="badge badge-primary">
                  {{ $product->quantity <1 ? 'No item is available': $product->quantity.' item in stock' }}
                </span></h5>
              <p>{{ $product->description }}</p>
              
             </div>
          </div>
        </div>
      </div>
      <!--Sidebar + Content End-->
      @endsection