 <div class="row">
     @foreach($products as $product)
     <div class="col-md-3">
       <div class="card text-center">
			@php $i = 1; @endphp
             @foreach($product->images as $image)
				 @if($i > 0)
                 <a href="{{ route('products.show', $product->slug) }}"> <img class="card-img-top feature-img" src="{{ asset('images/products/'. $image->image) }}" alt="{{ $product->title }}"></a>
                   @endif
                    @php $i--; @endphp
                  @endforeach

        <div class="card-body">
           <a href="{{ route('products.show', $product->slug) }}"> <h5 class="card-title">{{ $product->title }}</h5></a>
             <p class="card-text">Taka-{{ $product->price }}</p>
            @include('frontend.pages.product.partials.add_cart_button')
         </div>
         </div>
         </div>
          @endforeach
    </div>   
<br>
      <div class="pagination">	
      {{ $products->links() }}	
      </div> 