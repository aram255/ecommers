<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
--------------------------------------------------------------------------
 | Pages routes for frontend
 --------------------------------------------------------------------------
*/
Route::get('/', 'Frontend\PagesController@index')->name('index');



/*
--------------------------------------------------------------------------
 | Product routes frontend
 --------------------------------------------------------------------------
*/
Route::group(['prefix' => 'products'], function(){
  Route::get('/', 'Frontend\ProductsController@index')->name('products');
  Route::get('/{slug}', 'Frontend\ProductsController@show')->name('products.show');
  Route::get('/new/search', 'Frontend\PagesController@search')->name('search');

  // Category routes frontend
  Route::get('/categories', 'Frontend\CategoriesController@index')->name('categories.index');
  Route::get('/category/{id}', 'Frontend\CategoriesController@show')->name('categories.show');
});

// Add to Carts Route
Route::group(['prefix' => 'carts'], function(){
    Route::get('/', 'Frontend\CartsController@index')->name('carts');
 Route::post('/store', 'Frontend\CartsController@store')->name('carts.store');

});



/*
--------------------------------------------------------------------------
 | Admin routes for backend
 --------------------------------------------------------------------------
*/
Route::group(['prefix' => 'admin'], function(){
  Route::get('/', 'Backend\PagesController@index')->name('admin.index');
  
  // Product routes for backend 
  	Route::group(['prefix' => '/product'], function(){
  		Route::get('/manage', 'Backend\ProductsController@index')->name('admin.products.manage');
  		Route::get('/create', 'Backend\ProductsController@create')->name('admin.product.create');
	  	Route::post('/store', 'Backend\ProductsController@store')->name('admin.product.store');
	    Route::get('/edit/{id}', 'Backend\ProductsController@edit')->name('admin.product.edit');
	    Route::post('/update/{id}', 'Backend\ProductsController@update')->name('admin.product.update');
	    Route::post('/delete/{id}', 'Backend\ProductsController@delete')->name('admin.product.delete');
  	});


// Category routes for backend 
  	Route::group(['prefix' => '/categories'], function(){
  		Route::get('/', 'Backend\categoriesController@index')->name('admin.categories');
  		Route::get('/create', 'Backend\categoriesController@create')->name('admin.category.create');
	  	Route::post('/store', 'Backend\categoriesController@store')->name('admin.category.store');
	    Route::get('/edit/{id}', 'Backend\categoriesController@edit')->name('admin.category.edit');
	    Route::post('/update/{id}', 'Backend\categoriesController@update')->name('admin.category.update');
	    Route::post('/delete/{id}', 'Backend\categoriesController@delete')->name('admin.category.delete');
  	});

    // Brand routes for backend 
    Route::group(['prefix' => '/brands'], function(){
      Route::get('/', 'Backend\brandsController@index')->name('admin.brands');
      Route::get('/create', 'Backend\brandsController@create')->name('admin.brand.create');
      Route::post('/store', 'Backend\brandsController@store')->name('admin.brand.store');
      Route::get('/edit/{id}', 'Backend\brandsController@edit')->name('admin.brand.edit');
      Route::post('/update/{id}', 'Backend\brandsController@update')->name('admin.brand.update');
      Route::post('/delete/{id}', 'Backend\brandsController@delete')->name('admin.brand.delete');
    });  

    // Divisions routes for backend 
    Route::group(['prefix' => '/divisions'], function(){
      Route::get('/', 'Backend\divisionsController@index')->name('admin.divisions');
      Route::get('/create', 'Backend\divisionsController@create')->name('admin.division.create');
      Route::post('/store', 'Backend\divisionsController@store')->name('admin.division.store');
      Route::get('/edit/{id}', 'Backend\divisionsController@edit')->name('admin.division.edit');
      Route::post('/update/{id}', 'Backend\divisionsController@update')->name('admin.division.update');
      Route::post('/delete/{id}', 'Backend\divisionsController@delete')->name('admin.division.delete');
    });  

    // Districts routes for backend 
    Route::group(['prefix' => '/districts'], function(){
      Route::get('/', 'Backend\districtsController@index')->name('admin.districts');
      Route::get('/create', 'Backend\districtsController@create')->name('admin.district.create');
      Route::post('/store', 'Backend\districtsController@store')->name('admin.district.store');
      Route::get('/edit/{id}', 'Backend\districtsController@edit')->name('admin.district.edit');
      Route::post('/update/{id}', 'Backend\districtsController@update')->name('admin.district.update');
      Route::post('/delete/{id}', 'Backend\districtsController@delete')->name('admin.district.delete');
    });
  
});


// User Route
Route::group(['prefix' => 'user'], function(){
  Route::get('/token/{token}', 'Frontend\VerificationController@verify')->name('user.verification');
  Route::get('/dashboard', 'Frontend\UsersController@dashboard')->name('user.dashboard');
  Route::get('/profile', 'Frontend\UsersController@profile')->name('user.profile');
  Route::post('/profile/update', 'Frontend\UsersController@profileUpdate')->name('user.profile.update');
});
Auth::routes();




